package freemarker.ext.jsp;

import freemarker.template.TemplateModelException;

/**
 * @author Attila Szegedi
 * @version $Id: FreeMarkerPageContext1.java,v 1.1 2005/06/11 12:13:39 szegedia Exp $
 */
class FreeMarkerPageContext1 extends FreeMarkerPageContext {

    private FreeMarkerPageContext1() throws TemplateModelException {
        super();
    }
    
    static FreeMarkerPageContext create() throws TemplateModelException {
        return new FreeMarkerPageContext1();
    }
}
