package freemarker.ext.jsp;

import javax.servlet.jsp.el.ExpressionEvaluator;
import javax.servlet.jsp.el.VariableResolver;

import freemarker.template.TemplateModelException;

/**
 * @author Attila Szegedi
 * @version $Id: FreeMarkerPageContext2.java,v 1.1 2005/06/11 12:13:39 szegedia Exp $
 */
class FreeMarkerPageContext2 extends FreeMarkerPageContext {

    private FreeMarkerPageContext2() throws TemplateModelException {
        super();
    }

    static FreeMarkerPageContext create() throws TemplateModelException {
        return new FreeMarkerPageContext2();
    }

    public ExpressionEvaluator getExpressionEvaluator() {
        throw new UnsupportedOperationException();
    }
    
    public VariableResolver getVariableResolver() {
        throw new UnsupportedOperationException();
    }
    
    public void include(String arg0, boolean arg1) {
        throw new UnsupportedOperationException();
    }
}
